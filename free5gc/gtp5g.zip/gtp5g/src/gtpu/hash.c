#include <linux/jhash.h>

#include "hash.h"

u32 gtp5g_h_initval;
