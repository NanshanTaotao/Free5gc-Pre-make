#ifndef __UTIL_H__
#define __UTIL_H__

extern void ip_string(char *, int);

#endif // __UTIL_H__