#ifndef __API_VERSION_H__
#define __API_VERSION_H__

extern void set_far_action_u16(bool);
extern bool far_action_is_u16(void);

#endif // __API_VERSION_H__