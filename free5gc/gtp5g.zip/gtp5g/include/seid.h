#ifndef __SEID_H__
#define __SEID_H__

#include <linux/kernel.h>

extern void seid_and_u32id_to_hex_str(u64, u32, char *);

#endif // __SEID_H__