#ifndef __COMMON_H__
#define __COMMON_H__

#define MAX_PDR_PER_SESSION 0xFF

#endif // __COMMON_H__
